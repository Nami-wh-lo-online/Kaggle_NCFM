-- Tests for non Unicode engines

stdengine    = "pdftex"
checkengines = {"pdftex"}
checksearch  = false
checkdeps    = {maindir .. "/required/cyrillic"}
testfiledir  = "testfiles-legacy"
