-- Test with search tree enabled

checksearch  = true
testfiledir  = "./testfiles-search"

testsuppdir  = testfiledir .. "/support"
