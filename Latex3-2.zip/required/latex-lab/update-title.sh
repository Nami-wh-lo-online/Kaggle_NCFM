l3build save -cconfig-title -eluatex,pdftex \
	title-001 \
	title-002 \
	title-003 \
	title-004 \
	title-005 \
	title-006 \
	title-007 \
	title-008 
