-- Tests for math capture stuff

stdengine    = "luatex"
checkengines = {"luatex"}
checksearch  = true
testfiledir  = "testfiles-math-luatex"

checkruns     = 2


