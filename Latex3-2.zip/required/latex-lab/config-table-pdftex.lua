-- Tests for table stuff with pdftex

stdengine    = "pdftex"
checkengines = {"pdftex"}
checksearch  = true
testfiledir  = "testfiles-table-pdftex"

checkruns     = 2
forcecheckruns = true  --- for tagged stuff


