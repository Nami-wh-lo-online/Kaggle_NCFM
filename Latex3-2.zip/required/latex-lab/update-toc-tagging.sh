l3build save -epdftex,luatex -cconfig-toc \
    toc-ex-article-hyperref-1 \
    toc-ex-article-hyperref-2 \
    toc-ex-article-hyperref-2 \
    toc-ex-article-hyperref-3 \
    toc-ex-article-no-hyperref \
    toc-ex-article-no-tagging-hyperref \
    toc-ex-article-no-tagging \
    toc-ex-book-hyperref-1 \
    toc-ex-book-no-hyperref \
    toc-ex-book-tocdepth
