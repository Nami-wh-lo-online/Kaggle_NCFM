l3build save \
	documentmetadata-phase-II \
	new-or-001 \
        gh-tagging628-settodim


l3build save -epdftex,luatex \
	documentmetadata-support-000 \
	documentmetadata-support-001 \
	documentmetadata-support-002 \
	standard-a4f \
	tagging-gh34
