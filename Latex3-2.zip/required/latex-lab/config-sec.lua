-- Tests for sec tagging stuff

stdengine    = "pdftex"
checkengines = {"pdftex","luatex"}
checksearch  = true
testfiledir  = "testfiles-sec"

checkruns     = 2


