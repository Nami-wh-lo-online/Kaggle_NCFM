-- Tests for output routine stuff
--
-- Tests here only function locally due to the class not loaded in github actions!


checkengines = {"pdftex"}
checksearch  = true
testfiledir  = "testfiles-OR-local"

checkruns     = 3

