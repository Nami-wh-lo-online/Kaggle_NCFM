
l3build save -cconfig-math \
	math-suspended-gh661 \
	mathcapture-001 \
	mathcapture-002 \
	mathcapture-003 \
	mathcapture-004 \
	mathcapture-005 \
	mathcapture-006 \
	mathcapture-008 \
	mathcapture-009 \
	mathcapture-011 \
	mathcapture-012 \
	mathcapture-014 \
	mathcapture-015 \
	mathcapture-016 \
	mathcapture-017 \
	mathcapture-018 \
	mathcapture-019 \
	mtag-001 \
	mtag-002 \
	mtag-tlc3 \
        mathcapture-tag-001 \
	mtag-003 \
	mtag-004 \
	mtag-005-intertext


exit

	# with problems:
	
l3build save -cconfig-math \

exit

	mathcapture-007 \
	mathcapture-010 \
	mathcapture-013 \

	
