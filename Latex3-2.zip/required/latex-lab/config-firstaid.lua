-- Tests for firstaid
--
-- Tests here only function locally due to the class not loaded in github actions!


checkengines = {"pdftex"}
checksearch  = true
testfiledir  = "testfiles-firstaid"
-- excludetests={"test-cleveref"} -- doesn't work if firstaid is not in the format
checkruns     = 4

