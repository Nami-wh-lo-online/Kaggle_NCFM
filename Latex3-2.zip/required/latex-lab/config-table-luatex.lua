-- Tests for table stuff with luatex

stdengine    = "luatex"
checkengines = {"luatex"}
checksearch  = true
testfiledir  = "testfiles-table-luatex"

checkruns     = 2
forcecheckruns = true  --- for tagged stuff


