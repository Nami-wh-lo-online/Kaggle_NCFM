-- Tests for sec tagging stuff

stdengine    = "pdftex"
checkengines = {"pdftex","luatex"}
checksearch  = true
testfiledir  = "testfiles-toc"

checkruns     = 3
forcecheckruns = true  --- for tagged stuff


