
l3build save -cconfig-float -epdftex \
	marginpar-02


l3build save -cconfig-float -epdftex,luatex \
	float-001 \
	float-002 \
	float-003 \
	float-005-double \
	float-006-spacing \
	float-007-gh55 \
	float-010-outside \
	marginpar-01 \
	marginpar-03

exit
