l3build save -cconfig-table-pdftex \
	table-000 \
	table-001 \
	table-001-pdf \
	table-002 \
	table-003 \
	table-004-tabularx \
	table-005 \
	table-006-longtable \
	table-007-longtable \
	table-008-multi \
	table-008-disable \
	table-009 \
	table-009-pdf \
	table-010-longtable-pdf \
	table-010-longtable-pdf2 \
	table-011-endheadbox \
	table-012-caption \
	table-013-longtable-hyperref \
	table-014-pbox \
	table-014-pbox-longtable \
	table-015 \
	table-016 \
	table-016-math \
	table-017 \
	table-018 \
	table-019 \
	table-020 \
	table-021-longtable \
	table-022-cline

l3build save -cconfig-table-luatex \
	table-000 \
	table-001 \
	table-001-pdf \
	table-002 \
	table-003 \
	table-004-tabularx \
	table-005 \
	table-006-longtable \
	table-007-longtable \
	table-008-multi \
	table-009-pdf \
	table-009 \
	table-010-longtable-pdf \
	table-010-longtable-pdf2 \
	table-011-endheadbox \
	table-012-caption \
	table-013-longtable-hyperref \
	table-014-pbox \
	table-014-pbox-longtable \
	table-015 \
	table-016 \
	table-017 \
	table-018 \
	table-019 \
	table-020 \
	table-021-longtable

