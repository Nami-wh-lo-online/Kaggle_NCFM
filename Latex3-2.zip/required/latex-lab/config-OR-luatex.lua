testfiledir  = "testfiles-OR-luatex"
checkengines = {"luatex"}
stdengine     = "luatex"
checkruns    = 2
