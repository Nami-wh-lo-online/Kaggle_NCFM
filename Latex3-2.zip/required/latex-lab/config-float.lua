-- Tests for output routine stuff
--
-- Tests here only function locally due to the class not loaded in github actions!


checkengines = {"pdftex","luatex"}
checksearch  = true
testfiledir  = "testfiles-float"

checkruns     = 3

