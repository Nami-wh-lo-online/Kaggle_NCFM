

#l3build save -cconfig-minipage 


l3build save -epdftex,luatex -cconfig-minipage \
	minipage-001 \
	minipage-002-todo \
	minipage-003-todo \
	minipage-004-hyperref \
	minipage-005-footnote

exit




