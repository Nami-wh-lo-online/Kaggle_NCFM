-- Tests for LaTeX Manual (LM) tagging stuff

stdengine    = "pdftex"
checkengines = {"pdftex"}
checksearch  = true
testfiledir  = "testfiles-LM"
recordstatus = true
checkruns     = 3
forcecheckruns = true  --- for tagged stuff


