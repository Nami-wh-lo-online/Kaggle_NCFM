-- Tests for output routine stuff

checkengines = {"pdftex"}
checksearch  = true
testfiledir  = "testfiles-OR"

checkruns     = 2

