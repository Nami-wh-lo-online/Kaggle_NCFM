-- Tests for math tagging examples

stdengine    = "luatex"
checkengines = {"luatex"}
checksearch  = true
testfiledir  = "math-tagging-examples"

checkruns     = 2

recordstatus=true
