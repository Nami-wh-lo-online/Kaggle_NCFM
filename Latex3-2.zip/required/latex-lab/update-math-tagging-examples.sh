l3build save -cconfig-math-tagging-examples \
	math-20-default \
	math-20-mathmlAF+texAF \
	math-20-mathmlAF \
	math-20-alt-noluamml \
	math-20-alt \
	math-20-texAF-noluamml \
	math-20-texAF \
	math-20-alt+structelem+mathmlAF+texAF \
	math-20-structelem+mathmlAF+texAF \
	math-20-structelem \
	math-17-default \
	math-17-alt+mathmlAF+texAF \
	math-17-alt-noluamml \
	math-17-alt+structelem+rolemap+mathmlAF+texAF 


