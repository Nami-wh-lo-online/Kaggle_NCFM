-- Tests for minipage tagging stuff

stdengine    = "pdftex"
checkengines = {"pdftex","luatex"}
checksearch  = true
testfiledir  = "testfiles-minipage"

checkruns     = 3
forcecheckruns = true  --- for tagged stuff


