l3build save -epdftex,luatex -cconfig-sec \
     test-article-1 \
     test-book-1 \
     test-book-2 \
     test-faulty-nesting \
     test-stop-sect-pdf \
     test-stop-sect \
     test-suppress-sect
