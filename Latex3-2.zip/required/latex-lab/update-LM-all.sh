l3build save -cconfig-LM-tagging \
	LM-2-2 \
	LM-3-1+2 \
	LM-3-3 \
	LM-3-4
