-- Tests for block stuff

stdengine    = "pdftex"
checkengines = {"pdftex","luatex"}
checksearch  = true
testfiledir  = "testfiles-block"

checkruns     = 3
forcecheckruns = true  --- for tagged stuff


