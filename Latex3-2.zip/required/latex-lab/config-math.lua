-- Tests for math capture stuff

stdengine    = "pdftex"
checkengines = {"pdftex"}
checksearch  = true
testfiledir  = "testfiles-math"

checkruns     = 2


