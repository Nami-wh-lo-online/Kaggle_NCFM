-- Tests for graphic stuff


checkengines = {"luatex","pdftex"}
checksearch  = true
testfiledir  = "testfiles-graphic"

checkruns     = 2

