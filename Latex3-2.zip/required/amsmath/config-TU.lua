-- Tests for TU encoding

checkengines = {"xetex", "luatex"}
stdengine    = "xetex"
checksearch  = true
testfiledir  = "testfiles-TU"
