#!/usr/bin/env texlua

-- Build script for LaTeX "require" files

-- Never goes to CTAN but for testing
bundle = "required"
module = ""

-- Location of main directory: use Unix-style path separators
maindir = ".."
