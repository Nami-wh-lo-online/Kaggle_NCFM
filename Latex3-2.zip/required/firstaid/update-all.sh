l3build save \
	firstaid-000\
	firstaid-dinbrief \
	firstaid-index \
	firstaid-filehook

l3build save -cconfig-TU -exetex,luatex \
	firstaid-bidi
