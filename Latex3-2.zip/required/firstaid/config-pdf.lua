-- Tests needing \pdfoutput=1

stdengine    = "pdftex"
checkengines = {"pdftex"}
checksearch  = true
testfiledir  = "testfiles-pdf"
