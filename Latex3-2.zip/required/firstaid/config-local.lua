-- Tests not used with travis

stdengine    = "etex"
checkengines = {"etex"}
checksearch  = true
testfiledir  = "testfiles-local"
