-- Tests for ltcmd (from latex3/l3packages/xtemplate)

checkengines = {"pdftex"}
checksearch  = false
testfiledir  = "testfiles-lttemplates"

testsuppdir = "../support"

checkruns = 1
