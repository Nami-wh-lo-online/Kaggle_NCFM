
l3build save -cconfig-ltmarks \
	xmarks-001 \
	xmarks-002 \
	xmarks-003 \
	xmarks-004 \
	xmarks-005 \
	xmarks-006 \
	xmarks-007 \
	xmarks-008 \
	xmarks-009 \
	xmarks-009 \
	xmarks-010 \
	github-0836 \
	github-1359 \
	github-1359b


exit


