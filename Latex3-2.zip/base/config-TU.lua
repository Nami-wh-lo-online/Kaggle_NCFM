-- Tests for TU encoding

stdengine    = "xetex"
checkengines = {"xetex", "luatex"}
checksearch  = true
testfiledir  = "testfiles-TU"
