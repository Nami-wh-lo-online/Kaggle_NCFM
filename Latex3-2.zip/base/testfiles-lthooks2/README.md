Testfiles for hook management

 - pdftex only 
 - using 2 runs (to resolve page numbers)

