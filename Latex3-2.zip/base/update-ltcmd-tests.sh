
l3build save -cconfig-ltcmd \
   github-0569 \
   github-0569b \
   github-0639 \
   github-0963 \
   ltcmd000 \
   ltcmd001 \
   ltcmd002 \
   ltcmd003 \
   ltcmd004 \
   ltcmd005 \
   ltcmd006 \
   ltcmd007 \
   ltcmd008

l3build save -cconfig-ltcmd -eluatex \
   ltcmd002 \
   ltcmd004 \
   ltcmd005

exit


