-- Tests for lthooks

checkengines = {"pdftex"}
checksearch  = true
testfiledir  = "testfiles-lthooks2"

-- Custom settings for the check system
testsuppdir = "testfiles-lthooks2/helpers"


checkruns     = 2

