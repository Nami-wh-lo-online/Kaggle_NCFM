-- Tests for ltmarks

checkengines = {"pdftex"}
checksearch  = true
testfiledir  = "testfiles-ltmarks"

-- Custom settings for the check system

--testsuppdir = "testfiles-ltmarks/helpers"


checkruns     = 1

