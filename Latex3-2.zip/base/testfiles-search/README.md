The tests in this directory are *not* automatically run as part of the travis testing!

You need to run them locally with
```
l3build check -cconfig-search
```
