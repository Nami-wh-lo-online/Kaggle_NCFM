-- Tests for non Unicode engines

checkengines = {"pdftex"}
checksearch  = false
checkdeps    = {maindir .. "/required/cyrillic"}
testfiledir  = "testfiles-legacy"
