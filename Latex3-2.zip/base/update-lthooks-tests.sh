
l3build save -epdftex,luatex \
   github-0962b

l3build save -cconfig-lthooks2 \
   lthooks2-002 \
   lthooks2-004 \
   lthooks2-005 \
   lthooks2-006 \
   shipout2-emulations \
   shipout2-004 \
   shipout2-006 \
   shipout2-007 \
   shipout2-008 \
   shipout2-009 \
   shipout2-010 \
   shipout2-011 \
   shipout2-012 \
   shipout2-013 \
   shipout2-014 \
   shipout2-015 \
   shipout2-016 \
   shipout2-017 \
   github-0360  \
   github-0431  \
   ltpara-001 \
   ltpara-002 \
   ltpara-003 \
   ltpara-004 \
   ltpara-005 \
   ltpara-006 \
   ltpara-007 \
   ltpara-008



l3build save -cconfig-lthooks \
   ltcmdhooks-001 \
   ltcmdhooks-002 \
   ltcmdhooks-003 \
   ltcmdhooks-004 \
   ltcmdhooks-005 \
   ltcmdhooks-005a \
   ltcmdhooks-006 \
   ltcmdhooks-007 \
   ltcmdhooks-008 \
   ltcmdhooks-009 \
   ltcmdhooks-010 \
   ltcmdhooks-011 \
   filehook-001 \
   filehook-002 \
   filehook-003 \
   filehook-004 \
   filehook-005 \
   filehook-006 \
   filehook-007 \
   filehook-008 \
   filehook-009 \
   filehook-013 \
   filehook-bug-140 \
   lthooks-000 \
   lthooks-001 \
   lthooks-002 \
   lthooks-003 \
   lthooks-004 \
   lthooks-005 \
   lthooks-006 \
   lthooks-007 \
   lthooks-008 \
   lthooks-009 \
   lthooks-010 \
   lthooks-011 \
   lthooks-012 \
   lthooks-013 \
   lthooks-016 \
   lthooks-017 \
   lthooks-018 \
   lthooks-019 \
   lthooks-020 \
   lthooks-021 \
   lthooks-022 \
   lthooks-023 \
   lthooks-024 \
   lthooks-025 \
   lthooks-026 \
   lthooks-027 \
   lthooks-028 \
   lthooks-029 \
   lthooks-029-deprecated \
   lthooks-030 \
   lthooks-031 \
   lthooks-032 \
   lthooks-033 \
   lthooks-034 \
   lthooks-errors \
   lthooks-errors-deprecated \
   lthooks-etoolbox \
   lthooks-legacy \
   lthooks-doc-examples \
   lthooks-rollback-args \
   shipout-000 \
   shipout-002 \
   shipout-004 \
   shipout-005 \
   github-0379 \
   github-0387 \
   github-0401 \
   github-0464 \
   github-0565 \
   github-0606 \
   github-0648 \
   github-0648b \
   github-0818 \
   github-1459 \
   github-1591



exit


