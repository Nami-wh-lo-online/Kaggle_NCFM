-- Test with search tree enabled

-- checkengines = {"etex" }       -- use all engines

checksearch  = true
testfiledir  = "./testfiles-search"

testsuppdir  = testfiledir .. "/support"
