-- Tests for lthooks

checkengines = {"pdftex"}
checksearch  = false
testfiledir  = "testfiles-lthooks"

-- Custom settings for the check system
testsuppdir = "testfiles-lthooks/helpers"


checkruns     = 1

