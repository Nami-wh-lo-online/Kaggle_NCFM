-- Tests for non Unicode engines

checkengines = {"etex","xetex","luatex"}
stdengine    = "etex"
checksearch  = false
testfiledir  = "testfiles-filenames"
