-- Tests for ltcmd (from latex3/l3packages/xparse)

checksearch  = false
testfiledir  = "testfiles-ltcmd"

testsuppdir = "../support"

checkruns = 1
