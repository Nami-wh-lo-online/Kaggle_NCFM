# The LaTeX3 Development Repository (discussion papers)

## Overview

This is basically a pool area for thoughts (both on L3 as well as
on 2e and interface to 2e). Depending on how it grows this may get
split or moved eventually. None of what is discussed here is final or
should be taken as the direction in which we want to take things!


## Development team

LaTeX3 is developed by [The LaTeX3 Project](https://latex-project.org).

## Copyright

This README file is copyright 2018-2019 The LaTeX3 Project.
