#!/usr/bin/env texlua

-- Build script for LaTeX3 "l3doc" example files

module = "l3doc-examples"
