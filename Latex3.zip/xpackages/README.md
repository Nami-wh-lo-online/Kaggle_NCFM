This directory and its subdirectories contain a number of prototypes
made for earlier versions of expl3. None of them has be updated to the
current version of the language and some of them use concepts that we
now think are suboptimal.

They are only left here in case some of the stuff gets reused at some
point in the future. They are not meant to be used as is (well, they
can't) nor do should they be considered as models for other work for
the above reasons.
