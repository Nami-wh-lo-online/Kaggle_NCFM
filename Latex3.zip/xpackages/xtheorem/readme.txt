Module xtheorem
===============


Purpose:
--------

This is a prototype reimplementation of the AMS-LaTeX theorem
environments by Achim Blumensath.


To produce the documentation run:
---------------------------------

 latex xtheorem.dtx


To produce the package file xtheorem.sty run:
---------------------------------------------

 latex xtheorem.ins


To run the test file do:
------------------------

 latex xtheorem-test

You need the packages

 template.sty	(module xbase)
 xparse.sty	(module xbase)
 ldcsetup.sty	(module xbase)

to run the example file.



Enjoy
Frank Mittelbach 2000/01/02
