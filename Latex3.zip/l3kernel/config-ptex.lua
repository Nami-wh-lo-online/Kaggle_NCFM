checkengines = {"ptex"}
-- Make sure that any .tlg files are engine-specific
stdengine = "pdftex"
includetests =
  {
    "m3box001",
    "m3char001",
    "m3coffins001",
    "m3expl001",
    "m3expl002",
    "m3expl003",
    "m3expl006",
    "m3expl007",
    "m3int002",
    "m3ior001",
    "m3iow001",
    "m3pdf001",
    "m3sort001",
    "m3str-convert005",
    "m3str002",
    "m3text002",
    "m3text003",
    "m3text005"
  }