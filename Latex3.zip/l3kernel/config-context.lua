stdengine = "luametatex"
checkengines = {"luametatex","luatex"}
checkformat = "context"
testfiledir = "testfiles-context"
function checkinit_hook()
  return 0
end