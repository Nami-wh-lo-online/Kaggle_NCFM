checkformat = "tex"
testfiledir = "testfiles-plain"
checkengines = {"pdftex","xetex","luatex"}
function checkinit_hook()
  return 0
end
